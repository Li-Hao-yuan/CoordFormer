import sys, os

root_dir = os.path.join(os.path.dirname(__file__),'..')
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

import torch
import torch.nn as nn
import config
from config import args
from models.hrnet_32 import HigherResolutionNet
from models.transformer import Transformer
from loss_funcs import Loss
from maps_utils.result_parser import ResultParser
from models.base import Base

class PyramidLayer(nn.Module):
    BN_MOMENTUM = 0.1

    def __init__(self,in_channel,out_channel,kernel,padding):
        super(PyramidLayer,self).__init__()
        self.conv1 = nn.Conv2d(in_channel,in_channel,kernel,1,padding)
        self.bn1 = nn.BatchNorm2d(in_channel, momentum=0.1)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(in_channel,out_channel,kernel,1,padding)
        self.bn2 = nn.BatchNorm2d(out_channel, momentum=0.1)

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)

        out += residual
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        return out

class PyramidBlock(nn.Module):
    def __init__(self,channels,kernel):
        super(PyramidBlock,self).__init__()
        self.layers = nn.ModuleList([
                PyramidLayer(channels[0], channels[1], kernel, (kernel - 1) // 2),
                PyramidLayer(channels[1], channels[2], kernel, (kernel - 1) // 2),
                PyramidLayer(channels[2], channels[3], kernel, (kernel - 1) // 2),
            ])
    def forward(self,x):
        for layer in self.layers:
            x = layer(x)
        return x

class PyramidEncoder(nn.Module):
    def __init__(self):#[32,128,128]->[4,128,128]
        super(PyramidEncoder, self).__init__()

        channels = [32,16,8,4]
        self.enc_ker_3 = PyramidBlock(channels,3)
        self.enc_ker_5 = PyramidBlock(channels,5)
        self.enc_ker_7 = PyramidBlock(channels,7)
        self.enc_ker_9 = PyramidBlock(channels,9)
        self.down = nn.Sequential(
            nn.Conv2d(16,1,1,1),
            # nn.BatchNorm2d(1),
            nn.ReLU(inplace=True)
        )
        self.upsample = nn.UpsamplingBilinear2d(scale_factor=2)

    def forward(self,x):
        x = self.upsample(x) # ->[32,256,256]
        x_3 = self.enc_ker_3(x)
        x_5 = self.enc_ker_5(x)
        x_7 = self.enc_ker_7(x)
        x_9 = self.enc_ker_9(x)
        x = torch.cat((x_3,x_5,x_7,x_9),dim=1)
        out = self.down(x)

        return x,out

class PyramidDecoder(nn.Module):
    def __init__(self):#[32,128,128]->[4,128,128]
        super(PyramidDecoder, self).__init__()

        channels = [1,4,16,32]
        self.enc_ker_3 = PyramidBlock(channels,3)
        self.enc_ker_5 = PyramidBlock(channels,5)
        self.enc_ker_7 = PyramidBlock(channels,7)
        self.enc_ker_9 = PyramidBlock(channels,9)


    def forward(self,x):
        x_3 = self.enc_ker_3(x)
        x_5 = self.enc_ker_5(x)
        x_7 = self.enc_ker_7(x)
        x_9 = self.enc_ker_9(x)
        x = torch.cat((x_3,x_5,x_7,x_9),dim=1)

        return x

class VOMP(Base):
    def __init__(self, backbone=None,**kwargs):
        super(VOMP,self).__init__()
        def regression_head(final_channel=1):
            return nn.Sequential(
            nn.Conv2d(128, final_channel, 1, 1),
            # nn.BatchNorm2d(1),
            # nn.Tanh() if tanh else nn.Sigmoid(),
            nn.MaxPool2d(4),
        )

        self.backbone = backbone
        self.pyramid_enc = PyramidEncoder()
        self.pyramid_dec = PyramidDecoder()

        self.heatmap = regression_head(1)
        self.cameramap = regression_head(3)
        self.paramsmap = regression_head(142)

        self._result_parser = ResultParser()
        self.trans = Transformer()
        
        if args().model_return_loss:
            self._calc_loss = Loss()
        if not args().fine_tune and not args().eval:
            self.init_weights()
            self.backbone.load_pretrain_params()

    def head_forward(self,out):
        '''
        out : [batch_size,32,128,128]
        '''
        # dec_output = [batch_size,1,512,1024]
        # camera_map = [batch_size,3,64,64]
        # center_map = [batch_size,1,64,64]

        pyramid_output,trans_input = self.pyramid_enc(out)
        trans_output = self.trans(trans_input)
        pyramid_dec = self.pyramid_dec(trans_output)

        param_output = self.paramsmap(pyramid_dec)
        center_map = self.heatmap(pyramid_dec)
        camera_map = self.cameramap(pyramid_dec) #xxxx self.cameramap(pyramid_dec)

        camera_map[:,0] = torch.pow(1.1,camera_map[:,0])

        param_output = torch.cat([camera_map, param_output], 1)

        output = {'params_maps':param_output.float(),'center_map':center_map.float()} #, 'kp_ae_maps':kp_heatmap_ae.float()

        return output


if __name__ == "__main__":
    args().configs_yml = 'configs/v1.yml'
    args().model_version=1
    args().predict = True
    from models.build import build_model
    model = build_model().cuda()
    outputs=model.feed_forward({
        'image':torch.rand(2,512,512,3).cuda(),
        })

    print("ok!")