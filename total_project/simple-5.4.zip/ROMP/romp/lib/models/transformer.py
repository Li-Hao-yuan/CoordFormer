from tqdm import tqdm
import math
import torch
import numpy as np
import torch.nn as nn

import sys, os

root_dir = os.path.join(os.path.dirname(__file__), '..')
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

# import config
# from config import args


class PositionalEncoding(nn.Module):
    def __init__(self, emb_size, dropout=0.1, max_len=1000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_len, emb_size)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, emb_size, 2).float() * (-math.log(10000.0) / emb_size))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        '''
        x: [seq_len, batch_size, d_model]
        '''
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)


class Transformer(nn.Module):
    def __init__(self, src_len=256, emb_size=256, n_heads=4, num_layer=4):
        super(Transformer, self).__init__()

        # get value
        forward_dim = 2 * emb_size
        self.scr_len = src_len
        self.emb_size = emb_size

        # temporal embedding
        self.temporal_embedding = PositionalEncoding(emb_size)

        # encoder
        encoder_layer = nn.TransformerEncoderLayer(d_model=emb_size, nhead=n_heads,
                                                   dim_feedforward=forward_dim,
                                                   batch_first=True)  # [seq,batch,feature]->[batch,seq,feature]
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layer)

    def forward(self,x):
        x = x.squeeze(dim=1)
        assert x.shape[1] == self.scr_len
        assert x.shape[2] == self.emb_size

        out = self.temporal_embedding(x) # [~,src_len,emb_size]
        x = self.encoder(out)
        x = x.unsqueeze(dim=1)

        return x

# for test
def test_PE():
    emb_size = 256
    data = torch.rand(1, 256, emb_size).cuda()  # [batch_size,tgt_len,emb_size]

    PE = PositionalEncoding(emb_size).cuda()
    output = PE(data)  # [batch_size,tgt_len,emb_size]

    print(output.shape)
    print("PE ok")

def test_Trans():
    trans = Transformer().cuda()
    data = torch.rand(2, 256, 256).cuda()

    out = trans(data)
    print(out.shape)
    print("Trans ok")

if __name__ == "__main__":
    test_Trans()

