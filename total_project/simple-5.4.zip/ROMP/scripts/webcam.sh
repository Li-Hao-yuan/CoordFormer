CUDA_VISIBLE_DEVICES=0 python -u -m romp.predict.webcam --configs_yml='configs/webcam.yml'
