WEBCAM_CONFIGS='configs/webcam.yml'

python -u -m romp.lib.visualization.vis_server --configs_yml=${WEBCAM_CONFIGS} 