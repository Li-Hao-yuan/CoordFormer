CUDA_VISIBLE_DEVICES=0 python -u -m romp.predict.image --configs_yml='configs/image.yml'
