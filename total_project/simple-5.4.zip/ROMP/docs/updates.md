## Update logs

*2021/7/15: Adding support for an elegant context manager to run code in a notebook.*  See [Colab demo](https://colab.research.google.com/drive/1oz9E6uIbj4udOPZvA1Zi9pFx0SWH_UXg) for the details.  
*2021/4/19: Adding support for textured SMPL mesh using [vedo](https://github.com/marcomusy/vedo).* See [visualization.md](docs/visualization.md) for the details.  
*2021/3/30: 1.0 version.* Rebuilding the code. Release the ResNet-50 version and evaluation on 3DPW.   
*2020/11/26: Optimization for person-person occlusion.* Small changes for video support.   
*2020/9/11: Real-time webcam demo using local/remote server.* 
*2020/9/4: Google Colab demo.* Saving a npy file per imag. 
*2021/9/13: Low FPS / args parsing bugs are fixed. Support calling as a python lib.*   
*2021/9/10: Training code release. API optimization.*    
